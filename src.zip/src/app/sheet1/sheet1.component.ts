import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sheet1',
  templateUrl: './sheet1.component.html',
  styleUrls: ['./sheet1.component.css']
})
export class Sheet1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
